package com.team.fantasy.utils.crypto;

/**
 * Created by Sameer Jani on 29/1/18.
 */
public interface EncryptionGAE {
    String encryptGAE(String var1, String var2) throws Exception;

    String decryptGAE(String var1, String var2) throws Exception;
}
