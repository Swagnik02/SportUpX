package com.team.fantasy.Bean;

import java.util.ArrayList;


public class MyTeam {

    private ArrayList<BeanPlayerList> myteamList;

    public ArrayList<BeanPlayerList> getMyteamList() {
        return myteamList;
    }

    public void setMyteamList(ArrayList<BeanPlayerList> myteamList) {
        this.myteamList = myteamList;
    }
}
