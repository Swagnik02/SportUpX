package com.team.fantasy.Bean;



public class BeanMyTeamList {

    private String id;
    private String match_id;
    private String user_id;
    private String captain;
    private String vicecaptain;
    private String batsman;
    private String allrounder;
    private String wkeeper;
    private String team_number;
    private String boller;
    private String contest_id;
    private String entry_fees;
    private String team_id;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMatch_id() {
        return match_id;
    }

    public void setMatch_id(String match_id) {
        this.match_id = match_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCaptain() {
        return captain;
    }

    public void setCaptain(String captain) {
        this.captain = captain;
    }

    public String getVicecaptain() {
        return vicecaptain;
    }

    public void setVicecaptain(String vicecaptain) {
        this.vicecaptain = vicecaptain;
    }

    public String getBatsman() {
        return batsman;
    }

    public void setBatsman(String batsman) {
        this.batsman = batsman;
    }

    public String getAllrounder() {
        return allrounder;
    }

    public void setAllrounder(String allrounder) {
        this.allrounder = allrounder;
    }

    public String getWkeeper() {
        return wkeeper;
    }

    public void setWkeeper(String wkeeper) {
        this.wkeeper = wkeeper;
    }

    public String getTeam_number() {
        return team_number;
    }

    public void setTeam_number(String team_number) {
        this.team_number = team_number;
    }

    public String getBoller() {
        return boller;
    }

    public void setBoller(String boller) {
        this.boller = boller;
    }
    public void setEntry_fee(String entry_fees) {
        this.entry_fees = entry_fees;
    }

    public String getTeam_id() {
        return team_id;
    }

    public void setTeam_id(String team_id) {
        this.team_id = team_id;
    }
    public String getContest() {
        return contest_id;
    }
    public void setContest(String contest) {
        this.contest_id = contest_id;
    }

    public String getEntry_fee() {
        return entry_fees;
    }

}
