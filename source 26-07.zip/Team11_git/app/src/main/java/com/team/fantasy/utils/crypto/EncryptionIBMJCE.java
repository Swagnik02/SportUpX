package com.team.fantasy.utils.crypto;

/**
 * Created by Sameer Jani on 29/1/18.
 */
public interface EncryptionIBMJCE {
    String encryptIBMJCE(String var1, String var2) throws Exception;

    String decryptIBMJCE(String var1, String var2) throws Exception;
}
