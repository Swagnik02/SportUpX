package com.team.fantasy.Bean;



public class BeanPlayerSection {

    private String SectionLabel;
    private String PlayerData;

    public String getSectionLabel() {
        return SectionLabel;
    }

    public void setSectionLabel(String sectionLabel) {
        SectionLabel = sectionLabel;
    }


    public String getPlayerData() {
        return PlayerData;
    }

    public void setPlayerData(String playerData) {
        PlayerData = playerData;
    }
}
