package com.team.fantasy;

public class AppConfig {
    public static String ApiUrl = "https://cloudmint.tk/";
    public static String ApiKey = "auZv08ijho4QtIKk";
}
